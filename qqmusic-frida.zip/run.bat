@echo off
REM ============================================================
REM  QQ Music decryptor - drag a .mgg/.mflac FILE or FOLDER here
REM ============================================================
setlocal

if "%~1"=="" (
  echo.
  echo   Drag a .mgg or .mflac file, or a folder, onto this file.
  echo.
  pause
  exit /b 1
)

where python >nul 2>nul
if errorlevel 1 (
  echo.
  echo   [X] Python not found in PATH.
  echo       Install Python 3 from python.org and tick "Add Python to PATH".
  echo.
  pause
  exit /b 1
)

if not exist "%~dp0decrypt_frida.py" (
  echo.
  echo   [X] decrypt_frida.py not found next to this bat.
  echo       Unzip the WHOLE package.
  echo.
  pause
  exit /b 1
)

echo.
python "%~dp0decrypt_frida.py" %1
echo.
echo   --- exit code %errorlevel% ---
pause
