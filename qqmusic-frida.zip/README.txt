================================================================
  QQ 音乐借壳解密工具 (Frida)
================================================================

原理
----
  不获取密钥, 而是注入 QQ 音乐客户端进程,
  调用它自带的 QQMusicCommon.dll 的 EncAndDesMediaFile,
  让客户端自己完成「取钥 + 解密」, 把明文写出来。

  所以: 不需要密钥库, 不需要账号版权验证, 算法也不用逆向。
  只要客户端手里有这把 key, 它就能解。


安装
----
  1) 安装 Python 3
     https://www.python.org/downloads/
     ⚠️ 安装时务必勾选 "Add Python to PATH"

  2) 安装 frida
     打开命令提示符 (Win+R 输入 cmd), 运行:
         pip install frida
     如果提示版本不匹配, 试:
         pip install frida==16.2.2

  3) 启动 QQ 音乐 Windows 客户端, 并登录账号
     ⚠️ 重要: 建议先在客户端里播放或下载一次你要解密的那首歌。
        客户端必须先"见过"这个文件, 手里才有对应密钥。


使用
----
  方式 A: 单个文件
     把 .mgg / .mflac 文件拖到 run.bat 上松手。
     → 输出 <原名>.decrypted.mp3

  方式 B: 整个文件夹批量
     把文件夹拖到 run.bat 上松手 -> 递归处理所有加密音频,
     最后给出「成功 N, 失败 M」统计和失败明细。

  方式 C: 监听模式 (推荐, 省心)
     双击 watch.bat (或把文件夹拖到 watch.bat 上)
     -> 挂在那里不管, QQ 音乐下完新歌自动解密并转成 MP3
     -> Ctrl+C 退出

     监听模式会等文件「连续 6 秒大小不变」才处理,
     否则下载到一半的文件会被误当成品。


输出格式
--------
  默认直接输出 MP3 (320k), 中间的 .ogg 会被自动删掉。
  想改格式, 用命令行:

     python decrypt_frida.py --keep "D:\Music"          保留原 ogg
     python decrypt_frida.py --flac "D:\Music"          输出 FLAC 无损
     python decrypt_frida.py --bitrate 192k "D:\Music"  MP3 降到 192k 省空间

  转 MP3 需要 ffmpeg:
     下载 https://www.gyan.dev/ffmpeg/builds/ 的 full 版本,
     解压后把里面的 bin 文件夹加进系统 PATH。
     没装也能用 —— 脚本会保留 .ogg 并提示。

  ⚠️ MP3 本身是有损格式, 从 Vorbis 转 MP3 会再掉一次音质。
    如果你在意音质, 用 --flac (无损) 或 --keep (保留原始 ogg)。


输出位置
--------
  默认与源文件同目录。
  想输出到别处, 保持源目录干净:

     python decrypt_frida.py --watch "D:\Music" --out "D:\明文"


常见报错
--------
  [X] Illegal byte sequence / Non-ASCII path
      → 路径里有中文。v1.1 已自动处理 (中转到 ASCII 临时目录)。
        若仍出现, 说明系统临时目录也不纯英文, 手动设一个:
            set TMP=D:\tmp
        然后重开命令行再试。

  [X] 未能找到全部方法
      → QQ 音乐更新了, 内部符号签名变了, 工具需要适配。
        这不是你的问题。报错完整内容发给我, 我来适配新版。

  [X] EncAndDesMediaFile::Open 失败
      → 客户端「不认」这个文件。
        最可能的原因: 这个文件不是该客户端下载的,
        或者客户端的本地缓存里没有它。
        → 试试在 QQ 音乐里搜索并播放这一首, 再重试。

  [X] frida 版本 / 位数不匹配
      → 检查是不是 64 位 Python 对 64 位 QQMusic.exe:
            python -c "import frida,sys; print(frida.__version__, sys.maxsize)"
        sys.maxsize 要是 9223372036854775807 才是 64 位。

  [X] 未检测到 QQMusic.exe 进程
      → 客户端没开, 或者进程名不同。先开着客户端再运行。

  [X] 需要管理员权限
      → 右键 run.bat -> "以管理员身份运行"


关于控制台乱码 (v1.5)
---------------------
  如果你看到 [X] Failed: 一堆 "不是内部或外部命令" 之类的乱码,
  那是编码问题: 中文 Windows 的 cmd 是 GBK(CP936), 而 v1.4 之前的
  bat 存成了 UTF-8。

  v1.5 已彻底修复:
    - run.bat / watch.bat 全部改成纯 ASCII (一个中文都没有)
    - Python 的所有输出走 _p() 包装, 遇到 GBK 编不了的字符自动降级
    - 所以 emoji / 中文提示再也不会把监听循环搞崩

  你的 QQ 音乐下载的文件名可以是中文, 不影响。

注意
----
  - v1.1 已支持中文文件名 (自动中转到 ASCII 临时路径)
  - 需要管理员权限 (要注入别的进程)
  - 运行瞬间客户端可能卡一下, 正常现象
  - 不会修改客户端任何文件, 只是借用它的解密能力
  - 仅用于解密你自己合法下载、有权使用的音频文件


致谢
----
  思路来源:
    yllhwa/decrypt-mflac-frida   https://github.com/yllhwa/decrypt-mflac-frida
    ericjuice/music-decryptor    https://github.com/ericjuice/music-decryptor
  本实现取自 mzj3920/qqmusic-decrypt 的 frida_mode 独立重写版。