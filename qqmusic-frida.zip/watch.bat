@echo off
REM ============================================================
REM  Watch mode. Edit WATCH_DIR below, or drag a folder onto this file.
REM ============================================================
setlocal

set "WATCH_DIR=D:\Music\VipSongsDownload"
if not "%~1"=="" set "WATCH_DIR=%~1"

where python >nul 2>nul
if errorlevel 1 (
  echo.
  echo   [X] Python not found in PATH.
  echo       Install Python 3 from python.org and tick "Add Python to PATH".
  echo.
  pause
  exit /b 1
)

if not exist "%~dp0decrypt_frida.py" (
  echo.
  echo   [X] decrypt_frida.py missing. Unzip the WHOLE package.
  echo.
  pause
  exit /b 1
)

if not exist "%WATCH_DIR%" (
  echo.
  echo   [X] WATCH_DIR does not exist:
  echo         %WATCH_DIR%
  echo.
  echo   How to fix:
  echo     1. QQ Music  -^> Settings  -^> Download
  echo     2. Copy the exact download path
  echo     3. Edit WATCH_DIR above, or drag the folder onto watch.bat
  echo.
  pause
  exit /b 1
)

echo.
echo   ==================================================
echo    WATCH MODE
echo    dir  : %WATCH_DIR%
echo    stop : Ctrl+C
echo   ==================================================
echo   You should see a heartbeat line every 10 seconds.
echo.

python "%~dp0decrypt_frida.py" --watch "%WATCH_DIR%"
echo.
echo   --- exit code %errorlevel% ---
pause
